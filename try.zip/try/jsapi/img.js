// thie page contains the API keys to connect to the img API for the word input
const accessKey = "LD0F8mObz5Ox1EZ3R7tosY-jtaAM0KKj1Bb-2HZW5gk"
async function fetchDataImg() {
  const word = document.getElementById("word").value.toLocaleLowerCase();
  const url = `https://api.unsplash.com/search/photos?page=1&query=${word}&client_id=${accessKey}`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    const img = data.results[0].urls.full;
    var image = document.getElementById('image');
    image.src = img;
    image.style.display= "block";

    WORD_LIST.img_path = img

    console.log(data);

  } catch (error) {
    console.error(error);
  }
}

fetchData();
