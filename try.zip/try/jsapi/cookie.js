
// this file is to save the log in state by using the cookie 
// once log in successfully, the user may only access the logsuccess.php page 
// unless if they have hit the log out button 
document.addEventListener('DOMContentLoaded', function() {
    function getCookie(name) {
        let matches = document.cookie.match(new RegExp(
            "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
        ));
        return matches ? decodeURIComponent(matches[1]) : undefined;
    }
    var loggedIn = getCookie('loggedIn') === 'true';
    var accountLink = document.querySelector('a[href="http://localhost/try/htmlfiles/log_in.php"]');
    if (loggedIn && accountLink) {
        accountLink.href = 'http://localhost/try/htmlfiles/logsuccess.php';
    }
});

