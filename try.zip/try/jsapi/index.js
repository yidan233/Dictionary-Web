// the file contains the API code to connect to the dictionary API website
// to retrieve word definition and other information

// fetch = Function used for making HTTP requests to fetch resources.
//              (JSON style data, images, files)
//              Simplifies asynchronous data fetching in JavaScript and
//              used for interacting with APIs to retrieve and send
//              data asynchronously over the web.
//              fetch(url, {options})
async function fetchData() {
  const word = document.getElementById("word").value.toLocaleLowerCase();
  const url = `https://wordsapiv1.p.rapidapi.com/words/${word}`;
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': '376f35b4c3msh105440fbf94931ap135f0djsn150a11c38470',
      'X-RapidAPI-Host': 'wordsapiv1.p.rapidapi.com'
    }
  };

  try {
    const response = await fetch(url, options);
    const result = await response.json();

    // get the definition displayed in paragraph 1
    const definition = result.results[0].definition;
    var p1= document.getElementById('definition');
    p1.textContent = `definition :    ${definition}`;
    // type in p2
    const type = result.results[0].partOfSpeech;
    var p2= document.getElementById('type');
    p2.textContent = `type :   ${type}`;
    //  pronunciation in p4
    const pronunciation = result.pronunciation.all;
    var p2= document.getElementById('pronunciation');
    p2.textContent = `pronunciation :   ${pronunciation}`;
    // synonyms in p3
    const synonyms  = result.results[0].synonyms;
    var p2= document.getElementById('synonyms');
    p2.textContent = `synonyms : ${synonyms}`;

    // examples in p3
    const examples  = result.results[0].examples;
    var p2= document.getElementById('examples');
    p2.textContent = `examples : ${examples}`;


    WORD_LIST.definition = `${definition}`
    WORD_LIST.type = `${type}`
    WORD_LIST.pronunciation = `${pronunciation}`
    WORD_LIST.synonyms = `${synonyms}`
    WORD_LIST.examples = `${examples}`
    WORD_LIST.word = `${word}`

    console.log(`${ definition }`);
    console.log(result);
  // catch any error
  } catch (error) {
    console.error(error);
  }
}

fetchData();
