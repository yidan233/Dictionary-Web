var WORD_LIST  = {
  "word" : "",
  "definition" : "",
  "type" : "",
  "pronunciation" : "",
  "synomons" : "",
  "examples" : "",
  "img_path" : "",
}
