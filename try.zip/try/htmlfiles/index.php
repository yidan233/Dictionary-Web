<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='web_temp.css' rel='stylesheet'>
    <link rel="stylesheet" href="web_temp.css">
    <title>Yidan and Jess' dictionary </title>
    <script src="index.js"></script>
    <script src="img.js"></script>
</head>
<body>
 <div class="wrapper">
    <nav class="nav">
        <div class="logo">
            <p>Yidan and Jess 's dictionary </p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="#" class="link active">Search</a></li>
                <li><a href="wordlist.php" class="link">Word List</a></li>
                <li><a href="#" class="link">Quiz</a></li>
                <li><a href="#" class="link">account</a></li>
            </ul>
        </div>

    </nav>

<!----------------------------- search ----------------------------------->
<div>
    <div class="search-box">
      <div margin-bottom= 40px>
        <img class = "wordphoto" src=""alt = "word image" id="image"    style = "display:none">

        <div class="search-container" id="enter the word">
            <div class="input-box">
                <input type="text" id = "word"class="input-field" placeholder="search">
                <button class = search-button onclick="fetchData();fetchDataImg()"> search</button><br>
            </div>
        </div>
        <div class = 'search-paragraphs' id = paragraphs>
            <p id = "definition"> definition: </p>
            <p id = "type"> type: </p>
            <p id = "pronunciation"> pronunciation: </p>
            <p id = "synonyms">synomons:  </p>
            <p id = "examples">examples:  </p>

        </div>
    </div>
</div>
</body>
</html>