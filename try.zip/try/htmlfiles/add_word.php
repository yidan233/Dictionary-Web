<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once 'database.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $word = $_POST['word'];
    $definition = $_POST['definition'];
    $type = $_POST['type'];
    $pronunciation = mysqli_real_escape_string($conn, $_POST['pronunciation']);
    $synonyms = mysqli_real_escape_string($conn, $_POST['synonyms']);
    $examples = $_POST['examples'];
    $img_path = $_POST['img_path'];
    $uid = $_SESSION['uid'] ?: 0;
// 准备 SQL 语句并执行插入
    $sql = "INSERT INTO wordlist (`uid`,`word`, `definition`, `type`, `pronunciation`, `synomons`, `examples`, `img_path`) 
        VALUES ('{$uid}','$word', '$definition', '$type', '$pronunciation', '$synonyms', '$examples', '$img_path')";

    if (mysqli_query($conn, $sql)) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'msg' => 'option success'
        ]);exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
