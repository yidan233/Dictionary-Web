<!-- when the user click the account button and they have successfully log in their account
they will be transfered into this page, and not the log in page anymore-->
<?php
  include("database.php");
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>account information</title>
  <link href='web_temp.css' rel='stylesheet'>
  <link rel="stylesheet" href="web_temp.css">
  <title>Yidan and Jess' dictionary </title>
</head>
<body>
   <div class="wrapper">
    <nav class="nav">
        <div class="logo">
            <p>Yidan and Jess 's dictionary </p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="http://localhost/try/htmlfiles/search.php" class = "link" >Search</a></li>
                <li><a href="http://localhost/try/htmlfiles/wordlist.php" class="link">Word List</a></li>
               
                <li><a href="http://localhost/try/htmlfiles/log_in.php"  class="link active">account</a></li>
            </ul>
        </div>
    </nav>
    <div>
      <p > welcome, you have logged in !</p>
      <p> now you are able to access the world list function!</p>
      <form action = "logsuccess.php" method = "post">
        <input type = "submit" name = "logout" value = "logout">
      </form>
      
    </div>
</body>
</html>
<?php
  if (isset($_POST["logout"])) {
    session_destroy();
    setcookie('loggedIn', '', time() - 0, "/");
    header("Location: log_in.php");
  }
 
?>
