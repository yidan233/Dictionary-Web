<!-- when the user click "search" they will be transfered into this page -->
<!--the search page, where user can search for the word-->
<!-- start the server-->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='web_temp.css' rel='stylesheet'>
    <link rel="stylesheet" href="web_temp.css">
    <title>Yidan and Jess' dictionary </title>
    <script src="..\jsapi\img.js"></script>
    <script src="..\jsapi\data.js"></script>
    <script src="..\jsapi\index.js"></script>
    <script src="..\jsapi\cookie.js"></script>
</head>
<body>
<!--the dashboard at the top (the parts of code is the same for every web page)-->
 <div class="wrapper">
    <nav class="nav">
        <div class="logo">
            <p>Yidan and Jess 's dictionary </p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="http://localhost/try/htmlfiles/search.php" class = "link active" >Search</a></li>
                <li><a href="http://localhost/try/htmlfiles/wordlist.php" class="link">Word List</a></li>
                <li><a href="http://localhost/try/htmlfiles/quiz.php" class="link">Quiz</a></li>
                <li><a href="http://localhost/try/htmlfiles/log_in.php"  class="link">account</a></li>
            </ul>
        </div>
    </nav>

<!----------------------------- search ----------------------------------->
<div>
    <div class="search-box">
        <div class="image-container">
            <img class="wordphoto" src="" alt="word image" id="image" style="display:none">
        </div>
        <div class="search-container" id="enter-the-word">
            <div class="input-box">
                <input type="text" id="word" class="input-field" placeholder="search">
                <button class="search-button" onclick="fetchData(); fetchDataImg();">Search</button>
                <button class="add-button" onclick="addWord()">Add</button>
            </div>
        </div>
        <div class='search-paragraphs' id='paragraphs'>
            <p id="definition">definition:</p>
            <p id="type">type:</p>
            <p id="pronunciation">pronunciation:</p>
            <p id="synonyms">synonyms:</p>
            <p id="examples">examples:</p>
        </div>
    </div>
</div>
<script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    function addWord() {
        $.ajax({
            url: 'add_word.php',
            type: 'post',
            dataType: "json",
            data: WORD_LIST, // Ensure WORD_LIST is correctly defined and accessible
            success: function(res) {
                if (res.success == true) {
                    alert(res.msg);
                    window.location.reload();
                }
            },
            error: function() {
                alert('server_error');
            }
        });
    }
</script>
