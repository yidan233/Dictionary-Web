<!-- when the user click the account button, they will be transfered into this log_in.php
and once they have clicked the sign up link, they will go to this page (sign-up page) -->
<?php
// connect to the server
  include("database.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>account information</title>
  <link href='web_temp.css' rel='stylesheet'>
  <link rel="stylesheet" href="web_temp.css">
  <script src="..\jsapi\cookie.js"></script>
  <title>Yidan and Jess' dictionary </title>
</head>
<body>
   <div class="wrapper">
    <nav class="nav">
        <div class="logo">
            <p>Yidan and Jess 's dictionary </p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="http://localhost/try/htmlfiles/search.php" class = "link" >Search</a></li>
                <li><a href="http://localhost/try/htmlfiles/wordlist.php" class="link">Word List</a></li>
                
                <li><a href="http://localhost/try/htmlfiles/log_in.php"  class="link active">account</a></li>
            </ul>
        </div>
    </nav>



<!----------------------------- sign_up  ----------------------------------->
<div>
  <div class="form-container">
    <form action="#" method="post">
      <h2>sign up</h2>
      <div class="input-group">
        <input type="text" name="username" placeholder="username" required>
      </div>
      <div class="input-group">
        <input type="password" name="password" placeholder="password" required>
        <!-- jump back to the log in page -->
        <a href = "http://localhost/try/htmlfiles/log_in.php">log in</a>
      </div>

      <div class="input-group">
        <input type="submit" value="Sign up">
      </div>
    </form>
  </div>
</div>
</body>
</html>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
  $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);
  if (empty($username)) {
    echo "please enter a username";
  } elseif (empty($password)) {
    echo "please enter a password";
  } else {
    // encrypt the password
    $hash = password_hash($password, PASSWORD_DEFAULT);
    // add to the database
    $sql = "INSERT INTO users (user, password)
            VALUES ('$username','$hash')";
    try{
      // successfully registered
      mysqli_query($conn, $sql);
      echo ">      you are registered!".'<br>';
      echo ">      go to log in !";
    }
    catch (mysqli_sql_exception $e) {
      echo "that user name is taken, please try another one";

    }
  }
}
  mysqli_close($conn);
?>