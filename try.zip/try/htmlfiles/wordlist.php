<!-- when the user click the quiz link, they will be transfered into this page-->
<!-- only user who have logged in are able to access their wordlist,
 remeber to echo message to those user who havent log in, or you can use header to jump to the log in page
-->
<!-- add a button on the search.php page so the user may click that button to add word into they word list-->
<!-- the word list contains all the words that they have been searched for-->
<!-- try create a table that contains all of the words they have searched for or just simplying add a  column in the original table-->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>account information</title>
  <link href='web_temp.css' rel='stylesheet'>
  <link rel="stylesheet" href="web_temp.css">
  <script src="..\jsapi\cookie.js"></script>
  <title>Yidan and Jess' dictionary </title>
</head>
<body>
   <div class="wrapper">
    <nav class="nav">
        <div class="logo">
            <p>Yidan and Jess 's dictionary </p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="http://localhost/try/htmlfiles/search.php" class = "link" >Search</a></li>
                <li><a href="http://localhost/try/htmlfiles/wordlist.php" class="link active">Word List</a></li>
               
                <li><a href="http://localhost/try/htmlfiles/log_in.php"  class="link">account</a></li>
            </ul>
        </div>
    </nav>

<!----------------------------- quiz ----------------------------------->
<?php
// Ensure session is started

// Check if the user ID is set in the session
if (!isset($_SESSION['uid'])) {
    echo "User ID is not set in the session.";
    exit; // or handle the case where the session does not include uid
}

require_once 'database.php'; // Include your database connection settings

// Prepare a SQL statement
$sql = "SELECT * FROM `wordlist` WHERE uid = ?"; // Use placeholder for security
$stmt = $conn->prepare($sql); // Prepare the SQL statement

// Check if the preparation was successful
if (!$stmt) {
    echo "Failed to prepare statement";
    exit;
}

// Bind the session uid to the prepared SQL statement
$stmt->bind_param("i", $_SESSION['uid']); // 'i' denotes the type is integer

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo '<table border="1">';
    echo '<tr><th>Word</th><th>Definition</th><th>Type</th><th>Pronunciation</th><th>Synonyms</th><th>Examples</th><th>Created Time</th><th>Image</th></tr>';

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['word']) . '</td>';
        echo '<td>' . htmlspecialchars($row['definition']) . '</td>';
        echo '<td>' . htmlspecialchars($row['type']) . '</td>';
        echo '<td>' . htmlspecialchars($row['pronunciation']) . '</td>';
        echo '<td>' . htmlspecialchars($row['synomons']) . '</td>';
        echo '<td>' . htmlspecialchars($row['examples']) . '</td>';
        echo '<td>' . $row['create_time'] . '</td>';
        echo '<td><img src="' . htmlspecialchars($row['img_path']) . '" width="100"></td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo "No records found.";
}

// Close the statement
$stmt->close();
?>
